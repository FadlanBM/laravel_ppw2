<?php $__env->startSection('title', 'Edit Lowongan - Portal Lowongan Kerja'); ?>

<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('jobs.index')); ?>">Lowongan</a></li>
        <li class="breadcrumb-item active" aria-current="page">Edit</li>
    </ol>
</nav>

<div class="card border-0 shadow-sm">
    <div class="card-header bg-white py-3">
        <h4 class="mb-0 fw-bold"><i class="fa-solid fa-pen-to-square me-2 text-warning"></i>Edit Lowongan</h4>
        <p class="text-muted small mb-0 mt-1">Mengubah data lowongan <code>#<?php echo e($job->id); ?></code> milik <?php echo e($job->company); ?>.</p>
    </div>
    <div class="card-body p-4">
        <form action="<?php echo e(route('jobs.update', $job->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo $__env->make('jobs._form', ['submitLabel' => 'Perbarui Lowongan'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/fadlan/laravel_ppw2/resources/views/jobs/edit.blade.php ENDPATH**/ ?>