<?php $__env->startSection('title', 'Daftar Lowongan - Portal Lowongan Kerja'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-3 align-items-center">
    <div class="col-md-7">
        <h2 class="fw-bold text-dark m-0">Daftar Lowongan Kerja</h2>
        <p class="text-muted mb-0">Kelola lowongan yang tampil pada portal beserta logo perusahaan.</p>
    </div>
    <div class="col-md-5 text-md-end mt-3 mt-md-0">
        <a href="<?php echo e(route('jobs.create')); ?>" class="btn btn-success shadow-sm">
            <i class="fa-solid fa-plus me-1"></i> Tambah Lowongan
        </a>
    </div>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
        <i class="fa-solid fa-circle-check me-2"></i><?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<div class="row g-3 mb-4">
    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <p class="text-muted small mb-1">Total Lowongan</p>
                <h3 class="fw-bold mb-0"><?php echo e($statistik['total']); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <p class="text-muted small mb-1">Perusahaan Terdaftar</p>
                <h3 class="fw-bold mb-0"><?php echo e($statistik['perusahaan']); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <p class="text-muted small mb-1">Full-time</p>
                <h3 class="fw-bold mb-0"><?php echo e($statistik['full_time']); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <p class="text-muted small mb-1">Program Magang</p>
                <h3 class="fw-bold mb-0"><?php echo e($statistik['magang']); ?></h3>
            </div>
        </div>
    </div>
</div>

<div class="row row-cols-1 row-cols-md-2 row-cols-xl-3 g-4">
    <?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col">
            <div class="card h-100 border-0 shadow-sm">
                <div class="card-body d-flex flex-column">
                    <div class="d-flex align-items-start mb-3">
                        <?php if($job->logo): ?>
                            <img src="<?php echo e(asset('storage/'.$job->logo)); ?>" alt="Logo <?php echo e($job->company); ?>"
                                 class="rounded border bg-white me-3" style="width:64px;height:64px;object-fit:contain;">
                        <?php else: ?>
                            <div class="rounded border bg-light d-flex align-items-center justify-content-center me-3"
                                 style="width:64px;height:64px;">
                                <i class="fa-solid fa-building text-secondary fs-4"></i>
                            </div>
                        <?php endif; ?>
                        <div class="flex-grow-1">
                            <h5 class="fw-bold mb-1"><?php echo e($job->title); ?></h5>
                            <p class="text-muted small mb-1">
                                <i class="fa-solid fa-building-columns me-1"></i><?php echo e($job->company); ?>

                            </p>
                            <span class="badge <?php echo e($job->job_type_badge); ?>"><?php echo e($job->job_type_label); ?></span>
                        </div>
                    </div>

                    <p class="text-secondary small flex-grow-1"><?php echo e(Str::limit($job->description, 110)); ?></p>

                    <ul class="list-unstyled small text-muted mb-3">
                        <li class="mb-1"><i class="fa-solid fa-location-dot me-2"></i><?php echo e($job->location); ?></li>
                        <li><i class="fa-solid fa-money-bill-wave me-2"></i>
                            <?php echo e($job->salary_formatted ?? 'Gaji tidak dicantumkan'); ?>

                        </li>
                    </ul>

                    <div class="d-flex gap-2">
                        <a href="<?php echo e(route('jobs.show', $job->id)); ?>" class="btn btn-sm btn-outline-secondary">
                            <i class="fa-solid fa-eye"></i> Detail
                        </a>
                        <a href="<?php echo e(route('jobs.edit', $job->id)); ?>" class="btn btn-sm btn-warning text-dark">
                            <i class="fa-solid fa-pen-to-square"></i> Edit
                        </a>
                        <form action="<?php echo e(route('jobs.destroy', $job->id)); ?>" method="POST" class="ms-auto"
                              onsubmit="return confirm('Hapus lowongan <?php echo e($job->title); ?>?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger">
                                <i class="fa-solid fa-trash"></i> Hapus
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-body text-center py-5 text-muted">
                    <i class="fa-regular fa-folder-open fs-1 mb-3 d-block"></i>
                    Belum ada lowongan yang tersimpan. Mulai dengan menekan tombol Tambah Lowongan.
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<div class="d-flex justify-content-between align-items-center mt-4 flex-wrap gap-2">
    <div>
        <strong>Total data:</strong> <span class="badge bg-secondary fs-6"><?php echo e($jobs->total()); ?></span>
    </div>
    <div><?php echo e($jobs->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/fadlan/laravel_ppw2/resources/views/jobs/index.blade.php ENDPATH**/ ?>