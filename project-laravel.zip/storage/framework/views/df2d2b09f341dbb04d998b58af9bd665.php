<?php $__env->startSection('title', 'Tambah Lowongan - Portal Lowongan Kerja'); ?>

<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('jobs.index')); ?>">Lowongan</a></li>
        <li class="breadcrumb-item active" aria-current="page">Tambah</li>
    </ol>
</nav>

<div class="card border-0 shadow-sm">
    <div class="card-header bg-white py-3">
        <h4 class="mb-0 fw-bold"><i class="fa-solid fa-briefcase me-2 text-primary"></i>Tambah Lowongan</h4>
    </div>
    <div class="card-body p-4">
        <form action="<?php echo e(route('jobs.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo $__env->make('jobs._form', ['submitLabel' => 'Simpan Lowongan'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/fadlan/laravel_ppw2/resources/views/jobs/create.blade.php ENDPATH**/ ?>